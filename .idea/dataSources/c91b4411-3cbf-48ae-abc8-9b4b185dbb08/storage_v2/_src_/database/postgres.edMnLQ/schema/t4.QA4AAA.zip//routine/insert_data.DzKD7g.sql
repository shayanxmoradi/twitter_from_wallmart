create procedure insert_data(IN a integer, IN b integer)
    language sql
as
$$
INSERT INTO student VALUES (a);
INSERT INTO student VALUES (b);
$$;

alter procedure insert_data(integer, integer) owner to shayan;

