create function add_numbers(a integer, b integer) returns integer
    language plpgsql
as
$$
BEGIN
    RETURN a + b;
END;
$$;

alter function add_numbers(integer, integer) owner to shayan;

